package com.kara.mod;

import net.minecraftforge.common.config.Configuration;

import java.io.File;

public class KaraConfig {
    // ИИ-чат (любой OpenAI-совместимый API)
    public static String apiUrl;
    public static String apiKey;
    public static String model;
    public static String extraPrompt;
    public static boolean respondToAll;

    // Озвучка (OpenAI-совместимый /audio/speech), работает на клиенте
    public static boolean voiceEnabled;
    public static String ttsUrl;
    public static String ttsKey;
    public static String ttsModel;
    public static String ttsVoice;
    public static int ttsSampleRate;

    // Поведение
    public static int workRadius;
    public static boolean allowBreak;

    public static void load(File file) {
        Configuration c = new Configuration(file);
        c.load();

        apiUrl = c.getString("apiUrl", "ai", "https://api.openai.com/v1/chat/completions",
                "URL чат-API (OpenAI-совместимый: OpenAI, OpenRouter, DeepSeek и т.д.)");
        apiKey = c.getString("apiKey", "ai", "", "API-ключ. БЕЗ НЕГО KARA НЕ ОТВЕЧАЕТ НЕЙРОСЕТЬЮ.");
        model = c.getString("model", "ai", "gpt-4o-mini", "Модель");
        extraPrompt = c.getString("extraPrompt", "ai", "", "Дополнительные инструкции к характеру Kara");
        respondToAll = c.getBoolean("respondToAllChat", "ai", false,
                "true = отвечать на любое ваше сообщение; false = только если в сообщении есть 'Kara' или 'Кара'");

        voiceEnabled = c.getBoolean("voiceEnabled", "voice", true, "Включить озвучку (клиент)");
        ttsUrl = c.getString("ttsUrl", "voice", "https://api.openai.com/v1/audio/speech", "URL синтеза речи");
        ttsKey = c.getString("ttsKey", "voice", "", "Ключ для озвучки (пусто = использовать apiKey)");
        ttsModel = c.getString("ttsModel", "voice", "tts-1", "Модель озвучки");
        ttsVoice = c.getString("ttsVoice", "voice", "nova", "Голос (nova, shimmer, alloy ...)");
        ttsSampleRate = c.getInt("ttsSampleRate", "voice", 24000, 8000, 48000, "Частота PCM-ответа");

        workRadius = c.getInt("workRadius", "behavior", 10, 4, 24, "Радиус поиска блоков для работы");
        allowBreak = c.getBoolean("allowBreak", "behavior", true, "Разрешить Kara ломать блоки");

        if (c.hasChanged()) {
            c.save();
        }
    }

    public static String effectiveTtsKey() {
        return (ttsKey == null || ttsKey.isEmpty()) ? apiKey : ttsKey;
    }
}
