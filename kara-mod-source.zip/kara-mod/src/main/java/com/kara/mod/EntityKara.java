package com.kara.mod;

import net.minecraft.block.Block;
import net.minecraft.block.BlockFalling;
import net.minecraft.block.BlockLog;
import net.minecraft.block.ITileEntityProvider;
import net.minecraft.block.SoundType;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.IEntityLivingData;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.*;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.inventory.InventoryBasic;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.NonNullList;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.network.NetworkRegistry;

import javax.annotation.Nullable;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Set;
import java.util.UUID;

public class EntityKara extends EntityCreature {

    public enum Mode {FOLLOW, STAY}

    public enum Job {NONE, MINE, CHOP, BUILD}

    private static final String[] CHATTER = {
            "Ну что, красавчик, соскучился по мне?",
            "Ты так на меня смотришь... я же краснею, между прочим.",
            "Скажи «Кара» и что хочешь — я вся во внимании.",
            "Если будешь так мило тыкать в меня, я начну думать лишнее.",
            "Люблю, когда ты рядом. Особенно когда монстров нет.",
            "Работаю, защищаю, ещё и красива. Повезло тебе со мной."
    };

    private UUID ownerId;
    public Mode mode = Mode.FOLLOW;
    public Job job = Job.NONE;
    private String jobArg = "";
    public final InventoryBasic inv = new InventoryBasic("Kara", false, 27);

    private BlockPos target;
    private final Set<BlockPos> bad = new HashSet<>();
    private final LinkedList<BlockPos> buildQueue = new LinkedList<>();
    private int stuck, jobAge, workTimer;

    public EntityKara(World world) {
        super(world);
        setSize(0.6F, 1.8F);
        setCustomNameTag("Kara");
        setAlwaysRenderNameTag(true);
        enablePersistence();
    }

    // ---------- атрибуты и ИИ ----------

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(40.0D);
        getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.3D);
        getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).setBaseValue(40.0D);
        getAttributeMap().registerAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).setBaseValue(5.0D);
    }

    @Override
    protected void initEntityAI() {
        tasks.addTask(0, new EntityAISwimming(this));
        tasks.addTask(1, new EntityAIAttackMelee(this, 1.2D, true));
        tasks.addTask(4, new AIFollow());
        tasks.addTask(8, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
        tasks.addTask(9, new EntityAILookIdle(this));
        targetTasks.addTask(1, new EntityAIHurtByTarget(this, true));
        targetTasks.addTask(2, new EntityAINearestAttackableTarget<EntityLiving>(this, EntityLiving.class, 10, true, false,
                e -> e instanceof IMob));
    }

    @Nullable
    @Override
    public IEntityLivingData onInitialSpawn(DifficultyInstance difficulty, @Nullable IEntityLivingData data) {
        setItemStackToSlot(EntityEquipmentSlot.MAINHAND, new ItemStack(Items.IRON_SWORD));
        setItemStackToSlot(EntityEquipmentSlot.CHEST, new ItemStack(Items.IRON_CHESTPLATE));
        setItemStackToSlot(EntityEquipmentSlot.HEAD, new ItemStack(Items.IRON_HELMET));
        return super.onInitialSpawn(difficulty, data);
    }

    private class AIFollow extends EntityAIBase {
        AIFollow() {
            setMutexBits(3);
        }

        @Override
        public boolean shouldExecute() {
            EntityPlayer o = getOwner();
            return o != null && mode == Mode.FOLLOW && job == Job.NONE && getAttackTarget() == null
                    && getDistanceSq(o) > 25.0D;
        }

        @Override
        public boolean shouldContinueExecuting() {
            EntityPlayer o = getOwner();
            return o != null && mode == Mode.FOLLOW && job == Job.NONE && getAttackTarget() == null
                    && getDistanceSq(o) > 9.0D;
        }

        @Override
        public void updateTask() {
            EntityPlayer o = getOwner();
            if (o == null) return;
            if (getDistanceSq(o) > 576.0D) {
                getNavigator().clearPath();
                setPositionAndUpdate(o.posX + (rand.nextDouble() - 0.5) * 2, o.posY, o.posZ + (rand.nextDouble() - 0.5) * 2);
            } else {
                getNavigator().tryMoveToEntityLiving(o, 1.2D);
            }
        }
    }

    // ---------- владелец ----------

    public void setOwner(UUID id) {
        ownerId = id;
    }

    public boolean isOwnedBy(EntityPlayer p) {
        return ownerId != null && ownerId.equals(p.getUniqueID());
    }

    @Nullable
    public EntityPlayer getOwner() {
        return ownerId == null ? null : world.getPlayerEntityByUUID(ownerId);
    }

    // ---------- речь ----------

    public void speak(String text) {
        if (world.isRemote || text == null) return;
        TextComponentString m = new TextComponentString("§d<Kara> §f" + text);
        for (EntityPlayer p : world.getEntitiesWithinAABB(EntityPlayer.class, getEntityBoundingBox().grow(64))) {
            p.sendMessage(m);
        }
        KaraMod.NETWORK.sendToAllAround(new PacketKaraSpeak(text),
                new NetworkRegistry.TargetPoint(dimension, posX, posY, posZ, 48));
    }

    public String describeState(EntityPlayer p) {
        int blocks = 0;
        for (int i = 0; i < inv.getSizeInventory(); i++) {
            ItemStack s = inv.getStackInSlot(i);
            if (s.getItem() instanceof ItemBlock) blocks += s.getCount();
        }
        return String.format("[Состояние: твоё здоровье %.0f/%.0f, режим %s, работа %s, блоков в сумке %d, игрок %s (здоровье %.0f)]",
                getHealth(), getMaxHealth(), mode, job, blocks, p.getName(), p.getHealth());
    }

    // ---------- действия ----------

    public void applyAction(String action, String arg, EntityPlayer p) {
        String a = action == null ? "none" : action.toLowerCase();
        switch (a) {
            case "follow":
            case "guard":
                mode = Mode.FOLLOW;
                stopJob();
                break;
            case "stay":
                mode = Mode.STAY;
                stopJob();
                getNavigator().clearPath();
                break;
            case "mine":
                startJob(Job.MINE, arg);
                break;
            case "chop":
                startJob(Job.CHOP, arg);
                break;
            case "build":
                startBuild(p);
                break;
            case "give":
                dropInventoryTo(p);
                break;
            case "stop":
                stopJob();
                break;
            default:
                break;
        }
    }

    private void startJob(Job j, String arg) {
        if (!KaraConfig.allowBreak) {
            speak("Мне запретили ломать блоки, милый. Проверь конфиг.");
            return;
        }
        job = j;
        jobArg = arg == null ? "" : arg.toLowerCase();
        target = null;
        bad.clear();
        jobAge = 0;
        stuck = 0;
    }

    private void stopJob() {
        job = Job.NONE;
        target = null;
        buildQueue.clear();
        getNavigator().clearPath();
    }

    private void finish(String msg) {
        stopJob();
        speak(msg);
    }

    private void dropInventoryTo(@Nullable EntityPlayer p) {
        for (int i = 0; i < inv.getSizeInventory(); i++) {
            ItemStack s = inv.getStackInSlot(i);
            if (s.isEmpty()) continue;
            if (p != null) {
                if (!p.inventory.addItemStackToInventory(s)) p.dropItem(s, false);
            } else {
                entityDropItem(s, 0.5F);
            }
            inv.setInventorySlotContents(i, ItemStack.EMPTY);
        }
    }

    // ---------- работа ----------

    @Override
    public void onLivingUpdate() {
        updateArmSwingProgress();
        super.onLivingUpdate();
        if (!world.isRemote && isEntityAlive() && job != Job.NONE && getAttackTarget() == null) {
            runJob();
        }
    }

    private void runJob() {
        if (++workTimer % 4 != 0) return;
        jobAge += 4;
        if (jobAge > 6000) {
            finish("Всё, я выдохлась. Перерыв, красавчик.");
            return;
        }
        if (job == Job.BUILD) {
            buildStep();
            return;
        }

        if (target == null || !matches(world.getBlockState(target), target)) {
            target = findTarget();
            stuck = 0;
            if (target == null) {
                finish("Рядом больше ничего нет, милый. Пойдём дальше?");
                return;
            }
        }

        double cx = target.getX() + 0.5, cy = target.getY() + 0.5, cz = target.getZ() + 0.5;
        if (getDistanceSq(cx, cy, cz) > 20.0D) {
            boolean moved = getNavigator().tryMoveToXYZ(cx, target.getY(), cz, 1.2D);
            stuck += moved ? 4 : 12;
            if (stuck > 80) {
                BlockPos spot = standSpotNear(target);
                if (spot != null) {
                    setPositionAndUpdate(spot.getX() + 0.5, spot.getY(), spot.getZ() + 0.5);
                    stuck = 0;
                } else {
                    bad.add(target);
                    target = null;
                }
            }
            return;
        }

        getNavigator().clearPath();
        getLookHelper().setLookPosition(cx, cy, cz, 30F, 30F);
        swingArm(EnumHand.MAIN_HAND);
        IBlockState st = world.getBlockState(target);
        Block b = st.getBlock();
        NonNullList<ItemStack> drops = NonNullList.create();
        b.getDrops(drops, world, target, st, 0);
        world.destroyBlock(target, false);
        for (ItemStack s : drops) {
            ItemStack left = inv.addItem(s);
            if (!left.isEmpty()) entityDropItem(left, 0.5F);
        }
        target = null;
    }

    private boolean matches(IBlockState s, BlockPos pos) {
        Block b = s.getBlock();
        if (b == Blocks.AIR || s.getBlockHardness(world, pos) < 0) return false;
        if (pos.equals(getPosition().down())) return false;
        String name = b.getRegistryName() == null ? "" : b.getRegistryName().getResourcePath();
        switch (job) {
            case CHOP:
                return b instanceof BlockLog;
            case MINE:
                if ("stone".equals(jobArg)) {
                    return b == Blocks.STONE || b == Blocks.COBBLESTONE || b == Blocks.DIRT
                            || b == Blocks.SANDSTONE || b == Blocks.GRAVEL || b == Blocks.SAND;
                }
                return name.endsWith("_ore");
            default:
                return false;
        }
    }

    @Nullable
    private BlockPos findTarget() {
        int r = KaraConfig.workRadius;
        BlockPos c = getPosition();
        BlockPos best = null;
        double bd = Double.MAX_VALUE;
        for (int dx = -r; dx <= r; dx++) {
            for (int dy = -r; dy <= r; dy++) {
                for (int dz = -r; dz <= r; dz++) {
                    BlockPos p = c.add(dx, dy, dz);
                    double d = c.distanceSq(p);
                    if (d >= bd || bad.contains(p) || !world.isBlockLoaded(p)) continue;
                    if (matches(world.getBlockState(p), p)) {
                        best = p;
                        bd = d;
                    }
                }
            }
        }
        return best;
    }

    /** Ближайшее свободное место, где Kara может встать рядом с блоком (до 4 блоков от него). */
    @Nullable
    private BlockPos standSpotNear(BlockPos t) {
        BlockPos best = null;
        double bd = Double.MAX_VALUE;
        for (int dx = -4; dx <= 4; dx++) {
            for (int dy = -4; dy <= 4; dy++) {
                for (int dz = -4; dz <= 4; dz++) {
                    BlockPos p = t.add(dx, dy, dz);
                    double d = t.distanceSq(p);
                    if (d > 16.0D || d >= bd) continue;
                    if (world.isAirBlock(p) && world.isAirBlock(p.up())
                            && world.getBlockState(p.down()).getMaterial().isSolid()) {
                        best = p;
                        bd = d;
                    }
                }
            }
        }
        return best;
    }

    // ---------- стройка ----------

    private void startBuild(@Nullable EntityPlayer o) {
        EnumFacing f = o != null ? o.getHorizontalFacing() : getHorizontalFacing();
        BlockPos c = (o != null ? o.getPosition() : getPosition()).offset(f, 5);
        int y = c.getY() + 3;
        while (y > 1 && world.isAirBlock(new BlockPos(c.getX(), y - 1, c.getZ()))) y--;
        BlockPos base = new BlockPos(c.getX(), y, c.getZ());

        buildQueue.clear();
        for (int h = 0; h <= 3; h++) {
            for (int dx = -2; dx <= 2; dx++) {
                for (int dz = -2; dz <= 2; dz++) {
                    boolean edge = Math.max(Math.abs(dx), Math.abs(dz)) == 2;
                    if (h < 3 && !edge) continue;
                    // дверной проём со стороны игрока
                    if (h < 2 && dx == -f.getFrontOffsetX() * 2 && dz == -f.getFrontOffsetZ() * 2) continue;
                    buildQueue.add(base.add(dx, h, dz));
                }
            }
        }

        int have = 0;
        for (int i = 0; i < inv.getSizeInventory(); i++) {
            if (findBlockSlot() >= 0) {
                have = 1;
                break;
            }
        }
        if (have == 0) {
            buildQueue.clear();
            speak("У меня нет блоков, милый. Поручи мне накопать камня или срубить деревья.");
            return;
        }
        job = Job.BUILD;
        target = null;
        jobAge = 0;
        stuck = 0;
    }

    private int findBlockSlot() {
        for (int i = 0; i < inv.getSizeInventory(); i++) {
            ItemStack s = inv.getStackInSlot(i);
            if (s.isEmpty() || !(s.getItem() instanceof ItemBlock)) continue;
            Block b = ((ItemBlock) s.getItem()).getBlock();
            String name = b.getRegistryName() == null ? "" : b.getRegistryName().getResourcePath();
            if (b.getDefaultState().isFullCube() && !(b instanceof BlockFalling)
                    && !(b instanceof ITileEntityProvider) && !name.endsWith("_ore")) {
                return i;
            }
        }
        return -1;
    }

    private void buildStep() {
        if (buildQueue.isEmpty()) {
            finish("Готово! Нравится мой домик? Заходи, не стесняйся.");
            return;
        }
        BlockPos p = buildQueue.peek();
        if (!world.getBlockState(p).getBlock().isReplaceable(world, p)) {
            buildQueue.poll();
            return;
        }
        int slot = findBlockSlot();
        if (slot < 0) {
            finish("Блоки закончились, милый. Дострою, когда накопаю ещё.");
            return;
        }
        if (getDistanceSq(p.getX() + 0.5, p.getY() + 0.5, p.getZ() + 0.5) > 20.0D) {
            boolean moved = getNavigator().tryMoveToXYZ(p.getX() + 0.5, p.getY(), p.getZ() + 0.5, 1.2D);
            stuck += moved ? 4 : 12;
            if (stuck > 60) {
                BlockPos spot = standSpotNear(p);
                if (spot != null) setPositionAndUpdate(spot.getX() + 0.5, spot.getY(), spot.getZ() + 0.5);
                stuck = 0;
            }
            return;
        }
        stuck = 0;
        ItemStack st = inv.getStackInSlot(slot);
        ItemBlock ib = (ItemBlock) st.getItem();
        IBlockState state = ib.getBlock().getStateForPlacement(world, p, EnumFacing.UP, 0.5F, 0.5F, 0.5F,
                st.getMetadata(), this, EnumHand.MAIN_HAND);
        world.setBlockState(p, state, 3);
        SoundType sound = state.getBlock().getSoundType(state, world, p, this);
        world.playSound(null, p, sound.getPlaceSound(), SoundCategory.BLOCKS, 1.0F, 0.8F);
        st.shrink(1);
        if (st.isEmpty()) inv.setInventorySlotContents(slot, ItemStack.EMPTY);
        swingArm(EnumHand.MAIN_HAND);
        buildQueue.poll();
    }

    // ---------- взаимодействие ----------

    @Override
    protected boolean processInteract(EntityPlayer p, EnumHand hand) {
        if (world.isRemote || hand != EnumHand.MAIN_HAND) return true;
        if (ownerId == null) {
            ownerId = p.getUniqueID();
            speak("Наконец-то ты меня заметил, " + p.getName() + "... Теперь я вся твоя.");
            return true;
        }
        if (!isOwnedBy(p)) {
            speak("Эй, руки убрал. У меня уже есть хозяин.");
            return true;
        }
        if (p.isSneaking()) {
            dropInventoryTo(p);
            speak("Держи всё, что накопала. С тебя поцелуй... в щёку, конечно.");
            return true;
        }
        speak(CHATTER[rand.nextInt(CHATTER.length)]);
        return true;
    }

    @Override
    public void onDeath(DamageSource cause) {
        if (!world.isRemote) dropInventoryTo(null);
        super.onDeath(cause);
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENTITY_PLAYER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_PLAYER_DEATH;
    }

    // ---------- сохранение ----------

    @Override
    public void writeEntityToNBT(NBTTagCompound c) {
        super.writeEntityToNBT(c);
        if (ownerId != null) c.setUniqueId("Owner", ownerId);
        c.setString("Mode", mode.name());
        NBTTagList list = new NBTTagList();
        for (int i = 0; i < inv.getSizeInventory(); i++) {
            ItemStack s = inv.getStackInSlot(i);
            if (s.isEmpty()) continue;
            NBTTagCompound t = new NBTTagCompound();
            t.setByte("Slot", (byte) i);
            s.writeToNBT(t);
            list.appendTag(t);
        }
        c.setTag("KaraInv", list);
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound c) {
        super.readEntityFromNBT(c);
        if (c.hasUniqueId("Owner")) ownerId = c.getUniqueId("Owner");
        try {
            mode = Mode.valueOf(c.getString("Mode"));
        } catch (Exception ignored) {
            mode = Mode.FOLLOW;
        }
        NBTTagList list = c.getTagList("KaraInv", 10);
        for (int i = 0; i < list.tagCount(); i++) {
            NBTTagCompound t = list.getCompoundTagAt(i);
            int slot = t.getByte("Slot") & 255;
            if (slot < inv.getSizeInventory()) inv.setInventorySlotContents(slot, new ItemStack(t));
        }
    }
}
