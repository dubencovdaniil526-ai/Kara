package com.kara.mod;

public class CommonProxy {
    public void preInit() {
    }

    /** Проигрывание голоса — только на клиенте. */
    public void playVoice(String text) {
    }
}
