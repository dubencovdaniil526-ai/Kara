package com.kara.mod;

import com.google.gson.JsonObject;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.server.MinecraftServer;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ChatHandler {
    private static final ExecutorService POOL = Executors.newFixedThreadPool(2, r -> {
        Thread t = new Thread(r, "Kara-AI");
        t.setDaemon(true);
        return t;
    });

    private final Map<UUID, LinkedList<JsonObject>> history = new HashMap<>();

    @SubscribeEvent
    public void onChat(ServerChatEvent e) {
        final EntityPlayerMP p = e.getPlayer();
        final String msg = e.getMessage();

        List<EntityKara> list = p.world.getEntitiesWithinAABB(EntityKara.class,
                p.getEntityBoundingBox().grow(64), k -> k != null && k.isOwnedBy(p));
        if (list.isEmpty()) return;

        String low = msg.toLowerCase();
        boolean named = low.contains("kara") || low.contains("кара") || low.contains("кэра");
        if (!KaraConfig.respondToAll && !named) return;

        EntityKara nearest = list.get(0);
        for (EntityKara k : list) {
            if (k.getDistanceSq(p) < nearest.getDistanceSq(p)) nearest = k;
        }
        final EntityKara kara = nearest;

        if (KaraConfig.apiKey == null || KaraConfig.apiKey.isEmpty()) {
            kara.speak("Милый, вставь API-ключ в config/kara.cfg, а то я умею только загадочно молчать.");
            return;
        }

        final String ctx = kara.describeState(p);
        final List<JsonObject> snapshot;
        synchronized (history) {
            snapshot = new ArrayList<>(history.computeIfAbsent(kara.getUniqueID(), k -> new LinkedList<>()));
        }
        final MinecraftServer server = p.getServer();

        POOL.submit(() -> {
            AiClient.Reply reply = null;
            String err = null;
            try {
                reply = AiClient.ask(snapshot, ctx, msg);
            } catch (Exception ex) {
                err = ex.getMessage();
                KaraMod.LOGGER.warn("Kara AI error: " + err);
            }
            final AiClient.Reply r = reply;
            server.addScheduledTask(() -> {
                if (!kara.isEntityAlive()) return;
                if (r == null) {
                    kara.speak("Что-то со связью, милый. Загляни в лог — там причина.");
                    return;
                }
                kara.speak(r.say);
                kara.applyAction(r.action, r.arg, p);
                synchronized (history) {
                    LinkedList<JsonObject> h = history.computeIfAbsent(kara.getUniqueID(), k -> new LinkedList<>());
                    h.add(msgObj("user", msg));
                    h.add(msgObj("assistant", r.say));
                    while (h.size() > 12) h.removeFirst();
                }
            });
        });
    }

    private static JsonObject msgObj(String role, String content) {
        JsonObject o = new JsonObject();
        o.addProperty("role", role);
        o.addProperty("content", content);
        return o;
    }
}
