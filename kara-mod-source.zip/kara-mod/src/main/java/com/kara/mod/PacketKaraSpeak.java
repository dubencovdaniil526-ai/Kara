package com.kara.mod;

import io.netty.buffer.ByteBuf;
import net.minecraftforge.fml.common.network.ByteBufUtils;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

public class PacketKaraSpeak implements IMessage {
    public String text = "";

    public PacketKaraSpeak() {
    }

    public PacketKaraSpeak(String text) {
        this.text = text;
    }

    @Override
    public void fromBytes(ByteBuf buf) {
        text = ByteBufUtils.readUTF8String(buf);
    }

    @Override
    public void toBytes(ByteBuf buf) {
        ByteBufUtils.writeUTF8String(buf, text);
    }

    public static class Handler implements IMessageHandler<PacketKaraSpeak, IMessage> {
        @Override
        public IMessage onMessage(PacketKaraSpeak msg, MessageContext ctx) {
            KaraMod.proxy.playVoice(msg.text);
            return null;
        }
    }
}
