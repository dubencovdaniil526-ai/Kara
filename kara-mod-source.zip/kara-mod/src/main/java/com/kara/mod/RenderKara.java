package com.kara.mod;

import net.minecraft.client.model.ModelPlayer;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.layers.LayerBipedArmor;
import net.minecraft.client.renderer.entity.layers.LayerHeldItem;
import net.minecraft.util.ResourceLocation;

public class RenderKara extends RenderLiving<EntityKara> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(KaraMod.MODID, "textures/entity/kara.png");

    public RenderKara(RenderManager manager) {
        super(manager, new ModelPlayer(0.0F, true), 0.5F);
        this.addLayer(new LayerBipedArmor(this));
        this.addLayer(new LayerHeldItem(this));
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityKara entity) {
        return TEXTURE;
    }
}
