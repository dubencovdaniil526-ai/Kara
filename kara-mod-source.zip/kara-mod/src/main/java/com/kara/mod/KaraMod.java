package com.kara.mod;

import net.minecraft.util.ResourceLocation;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import net.minecraftforge.fml.common.registry.EntityRegistry;
import net.minecraftforge.fml.relauncher.Side;
import org.apache.logging.log4j.Logger;

@Mod(modid = KaraMod.MODID, name = "Kara AI Companion", version = "1.0.0", acceptedMinecraftVersions = "[1.12.2]")
public class KaraMod {
    public static final String MODID = "kara";

    @Mod.Instance(MODID)
    public static KaraMod instance;

    @SidedProxy(clientSide = "com.kara.mod.ClientProxy", serverSide = "com.kara.mod.CommonProxy")
    public static CommonProxy proxy;

    public static SimpleNetworkWrapper NETWORK;
    public static Logger LOGGER;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent e) {
        LOGGER = e.getModLog();
        KaraConfig.load(e.getSuggestedConfigurationFile());

        EntityRegistry.registerModEntity(new ResourceLocation(MODID, "kara"), EntityKara.class, "kara", 0,
                this, 64, 1, true, 0xFF69B4, 0x2B1B17);

        NETWORK = NetworkRegistry.INSTANCE.newSimpleChannel(MODID);
        NETWORK.registerMessage(PacketKaraSpeak.Handler.class, PacketKaraSpeak.class, 0, Side.CLIENT);

        proxy.preInit();
        MinecraftForge.EVENT_BUS.register(new ChatHandler());
    }

    @Mod.EventHandler
    public void serverStarting(FMLServerStartingEvent e) {
        e.registerServerCommand(new CommandKara());
    }
}
