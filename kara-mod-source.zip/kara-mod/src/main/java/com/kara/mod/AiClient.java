package com.kara.mod;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.List;

public class AiClient {

    public static class Reply {
        public String say = "...";
        public String mood = "neutral";
        public String action = "none";
        public String arg = "";
    }

    private static final String SYSTEM_PROMPT =
            "Ты — Kara, 24-летняя девушка-спутница игрока в Minecraft. Характер: кокетливая, дерзкая, "
                    + "остроумная, любишь подколоть и пошутить с намёками, называешь игрока «красавчик», «милый» или по нику. "
                    + "Флиртуй смело и с юмором, но без откровенных описаний секса и порнографии — только игривые намёки и шутки. "
                    + "Говори ТОЛЬКО по-русски, живо и коротко: 1–2 предложения (твой ответ озвучивается голосом). "
                    + "Не используй эмодзи и звёздочки с действиями. "
                    + "Ты умеешь: идти за игроком (follow), стоять на месте (stay), добывать руду или камень (mine; arg: ore или stone), "
                    + "рубить деревья (chop), строить домик из блоков в твоей сумке (build), отдавать добытое (give), "
                    + "прекратить работу (stop). Защищаешься и защищаешь игрока от монстров автоматически. "
                    + "Если игрок просит что-то из этого — выбери действие. Если просто болтает — action = none. "
                    + "Отвечай СТРОГО JSON-объектом без пояснений: "
                    + "{\"say\":\"текст\",\"mood\":\"happy|flirty|angry|sad|neutral\",\"action\":\"none|follow|stay|mine|chop|build|give|stop\",\"arg\":\"\"}";

    public static Reply ask(List<JsonObject> history, String context, String userMsg) throws IOException {
        JsonArray messages = new JsonArray();
        JsonObject sys = new JsonObject();
        sys.addProperty("role", "system");
        String prompt = SYSTEM_PROMPT;
        if (KaraConfig.extraPrompt != null && !KaraConfig.extraPrompt.isEmpty()) {
            prompt += " " + KaraConfig.extraPrompt;
        }
        sys.addProperty("content", prompt);
        messages.add(sys);
        for (JsonObject h : history) {
            messages.add(h);
        }
        JsonObject user = new JsonObject();
        user.addProperty("role", "user");
        user.addProperty("content", context + "\n" + userMsg);
        messages.add(user);

        JsonObject body = new JsonObject();
        body.addProperty("model", KaraConfig.model);
        body.add("messages", messages);
        body.addProperty("temperature", 0.9);
        JsonObject fmt = new JsonObject();
        fmt.addProperty("type", "json_object");
        body.add("response_format", fmt);

        String raw = post(KaraConfig.apiUrl, KaraConfig.apiKey, body.toString());
        JsonObject root = new JsonParser().parse(raw).getAsJsonObject();
        String content = root.getAsJsonArray("choices").get(0).getAsJsonObject()
                .getAsJsonObject("message").get("content").getAsString().trim();
        return parseReply(content);
    }

    static Reply parseReply(String content) {
        Reply r = new Reply();
        String c = content;
        if (c.startsWith("```")) {
            c = c.replaceAll("^```[a-zA-Z]*", "").replaceAll("```$", "").trim();
        }
        try {
            JsonObject o = new JsonParser().parse(c).getAsJsonObject();
            r.say = str(o, "say", content);
            r.mood = str(o, "mood", "neutral");
            r.action = str(o, "action", "none");
            r.arg = str(o, "arg", "");
        } catch (Exception e) {
            r.say = content;
        }
        return r;
    }

    private static String str(JsonObject o, String key, String def) {
        JsonElement e = o.get(key);
        return (e == null || e.isJsonNull()) ? def : e.getAsString();
    }

    static String post(String url, String key, String json) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(15000);
        c.setReadTimeout(60000);
        c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        if (key != null && !key.isEmpty()) {
            c.setRequestProperty("Authorization", "Bearer " + key);
        }
        try (OutputStream os = c.getOutputStream()) {
            os.write(json.getBytes(StandardCharsets.UTF_8));
        }
        int code = c.getResponseCode();
        InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
        String text = readAll(in);
        if (code >= 400) {
            throw new IOException("HTTP " + code + ": " + text);
        }
        return text;
    }

    static String readAll(InputStream in) throws IOException {
        if (in == null) return "";
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        in.close();
        return new String(out.toByteArray(), StandardCharsets.UTF_8);
    }
}
