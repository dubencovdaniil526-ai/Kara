package com.kara.mod;

import net.minecraftforge.fml.client.registry.RenderingRegistry;

public class ClientProxy extends CommonProxy {
    @Override
    public void preInit() {
        RenderingRegistry.registerEntityRenderingHandler(EntityKara.class, manager -> new RenderKara(manager));
    }

    @Override
    public void playVoice(String text) {
        ClientVoice.speak(text);
    }
}
