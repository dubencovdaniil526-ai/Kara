package com.kara.mod;

import com.google.gson.JsonObject;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.SourceDataLine;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Русская озвучка: запрашивает PCM у TTS-API и проигрывает через javax.sound. Только клиент. */
public class ClientVoice {
    private static final ExecutorService EX = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "Kara-Voice");
        t.setDaemon(true);
        return t;
    });

    public static void speak(String text) {
        if (!KaraConfig.voiceEnabled || text == null) return;
        final String clean = text.replaceAll("\\*[^*]*\\*", "").trim();
        if (clean.isEmpty()) return;
        EX.submit(() -> {
            try {
                byte[] pcm = fetch(clean);
                play(pcm);
            } catch (Exception e) {
                KaraMod.LOGGER.warn("Kara voice error: " + e.getMessage());
            }
        });
    }

    private static byte[] fetch(String text) throws Exception {
        JsonObject body = new JsonObject();
        body.addProperty("model", KaraConfig.ttsModel);
        body.addProperty("input", text);
        body.addProperty("voice", KaraConfig.ttsVoice);
        body.addProperty("response_format", "pcm");

        HttpURLConnection c = (HttpURLConnection) new URL(KaraConfig.ttsUrl).openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(15000);
        c.setReadTimeout(60000);
        c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        String key = KaraConfig.effectiveTtsKey();
        if (key != null && !key.isEmpty()) c.setRequestProperty("Authorization", "Bearer " + key);
        try (OutputStream os = c.getOutputStream()) {
            os.write(body.toString().getBytes(StandardCharsets.UTF_8));
        }
        int code = c.getResponseCode();
        if (code >= 400) {
            throw new RuntimeException("TTS HTTP " + code);
        }
        try (InputStream in = c.getInputStream()) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toByteArray();
        }
    }

    private static void play(byte[] pcm) throws Exception {
        AudioFormat fmt = new AudioFormat(KaraConfig.ttsSampleRate, 16, 1, true, false);
        SourceDataLine line = AudioSystem.getSourceDataLine(fmt);
        line.open(fmt);
        line.start();
        line.write(pcm, 0, pcm.length - (pcm.length % 2));
        line.drain();
        line.close();
    }
}
