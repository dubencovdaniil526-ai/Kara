package com.kara.mod;

import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;

import java.util.List;

public class CommandKara extends CommandBase {
    @Override
    public String getName() {
        return "kara";
    }

    @Override
    public String getUsage(ICommandSender sender) {
        return "/kara spawn | dismiss | status | do <follow|stay|mine|chop|build|give|stop> [ore|stone]";
    }

    @Override
    public int getRequiredPermissionLevel() {
        return 0;
    }

    @Override
    public boolean checkPermission(MinecraftServer server, ICommandSender sender) {
        return true;
    }

    @Override
    public void execute(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
        EntityPlayerMP p = getCommandSenderAsPlayer(sender);
        String sub = args.length > 0 ? args[0].toLowerCase() : "help";
        switch (sub) {
            case "spawn": {
                BlockPos pos = p.getPosition().offset(p.getHorizontalFacing(), 2);
                EntityKara k = new EntityKara(p.world);
                k.setLocationAndAngles(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, p.rotationYaw + 180F, 0F);
                k.onInitialSpawn(p.world.getDifficultyForLocation(pos), null);
                k.setOwner(p.getUniqueID());
                p.world.spawnEntity(k);
                k.speak("Привет, " + p.getName() + ". Я Kara. Скажи «Кара» и что-нибудь — и я отвечу... с удовольствием.");
                break;
            }
            case "dismiss": {
                List<EntityKara> list = owned(p, 256);
                for (EntityKara k : list) k.setDead();
                sender.sendMessage(new TextComponentString("Kara отпущена: " + list.size()));
                break;
            }
            case "status": {
                EntityKara k = nearest(p);
                sender.sendMessage(new TextComponentString(k == null ? "Kara рядом нет." : k.describeState(p)));
                break;
            }
            case "do": {
                EntityKara k = nearest(p);
                if (k == null) {
                    sender.sendMessage(new TextComponentString("Kara рядом нет. /kara spawn"));
                    break;
                }
                k.applyAction(args.length > 1 ? args[1] : "none", args.length > 2 ? args[2] : "", p);
                break;
            }
            default:
                sender.sendMessage(new TextComponentString(getUsage(sender)));
        }
    }

    private static List<EntityKara> owned(EntityPlayerMP p, int range) {
        return p.world.getEntitiesWithinAABB(EntityKara.class, p.getEntityBoundingBox().grow(range),
                k -> k != null && k.isOwnedBy(p));
    }

    private static EntityKara nearest(EntityPlayerMP p) {
        EntityKara best = null;
        for (EntityKara k : owned(p, 128)) {
            if (best == null || k.getDistanceSq(p) < best.getDistanceSq(p)) best = k;
        }
        return best;
    }
}
